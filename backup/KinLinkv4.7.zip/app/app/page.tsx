'use client';

import React, { useEffect, useState, useCallback, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { Heart, Loader2 } from 'lucide-react';
import { useKindLinkStore } from '@/lib/store/useKindLinkStore';
import { createClient } from '@/lib/supabase/client';
import { Header } from '@/components/shell/Header';
import { Sidebar } from '@/components/shell/Sidebar';
import { BottomTabBar } from '@/components/shell/BottomTabBar';
import { HomeView } from '@/components/home/HomeView';
import { RequestsView } from '@/components/requests/RequestsView';
import { MapView } from '@/components/map/MapView';
import { NewRequestWizard } from '@/components/wizard/NewRequestWizard';
import { ProfileView } from '@/components/profile/ProfileView';
import { SettingsView } from '@/components/settings/SettingsView';
import { WelcomeModal } from '@/components/onboarding/WelcomeModal';
import { AutoLanguageNotice } from '@/components/locale/AutoLanguageNotice';
import { CommandPalette } from '@/components/shell/CommandPalette';
import { initializeRealtime } from '@/lib/supabase/realtime';

export default function KindLinkApp() {
  const router = useRouter();
  const mainRef = useRef<HTMLElement>(null);
  const {
    currentView,
    fetchLiveRequests,
    fetchLiveStats,
    fetchLiveProfile,
    fetchLiveNotifications,
  } = useKindLinkStore();

  const [authChecking, setAuthChecking] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const supabase = createClient();

  const loadAppData = useCallback(async () => {
    await Promise.allSettled([
      fetchLiveProfile(),
      fetchLiveRequests(),
      fetchLiveStats(),
      fetchLiveNotifications(),
    ]);
  }, [fetchLiveProfile, fetchLiveRequests, fetchLiveStats, fetchLiveNotifications]);

  // 1 & 2. Check auth session on mount; if no session, redirect to /login
  useEffect(() => {
    let isMounted = true;

    async function checkAuthSession() {
      try {
        const {
          data: { session },
          error,
        } = await supabase.auth.getSession();

        if (!isMounted) return;

        if (error || !session?.user) {
          setIsAuthenticated(false);
          setAuthChecking(false);
          router.push('/login?redirect=/app');
          return;
        }

        // 3. If session exists, load user profile and show main app
        setIsAuthenticated(true);
        await loadAppData();
      } catch (err) {
        console.warn('Session verification exception:', err);
        if (isMounted) {
          setIsAuthenticated(false);
          router.push('/login?redirect=/app');
        }
      } finally {
        if (isMounted) {
          setAuthChecking(false);
        }
      }
    }

    checkAuthSession();

    // Listen to realtime auth state changes
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (!isMounted) return;

      if (session?.user) {
        setIsAuthenticated(true);
        setAuthChecking(false);
        await loadAppData();
      } else {
        setIsAuthenticated(false);
        setAuthChecking(false);
        router.push('/login?redirect=/app');
      }
    });

    return () => {
      isMounted = false;
      subscription?.unsubscribe();
    };
  }, [supabase, router, loadAppData]);

  // Bind realtime subscriptions when session is confirmed
  useEffect(() => {
    if (!isAuthenticated) return;

    const cleanupRealtime = initializeRealtime();

    return () => {
      cleanupRealtime?.();
    };
  }, [isAuthenticated]);

  // Set manual scroll restoration on mount while preserving browser back/forward if history state has a position
  useEffect(() => {
    if (typeof window !== 'undefined') {
      if ('scrollRestoration' in window.history) {
        window.history.scrollRestoration = 'manual';
      }

      const handlePopState = (event: PopStateEvent) => {
        if (event.state && typeof event.state.scrollY === 'number') {
          window.scrollTo(0, event.state.scrollY);
          if (mainRef.current && typeof event.state.mainScrollTop === 'number') {
            mainRef.current.scrollTop = event.state.mainScrollTop;
          }
        }
      };

      window.addEventListener('popstate', handlePopState);

      const state = window.history.state;
      if (state && typeof state.scrollY === 'number') {
        window.scrollTo(0, state.scrollY);
        if (mainRef.current && typeof state.mainScrollTop === 'number') {
          mainRef.current.scrollTop = state.mainScrollTop;
        }
      } else {
        window.scrollTo(0, 0);
        if (mainRef.current) {
          mainRef.current.scrollTop = 0;
        }
      }

      return () => {
        window.removeEventListener('popstate', handlePopState);
      };
    }
  }, []);

  // When switching currentView (e.g. from home to profile, or between views), ensure window.scrollTo(0, 0) and reset main scroll position to 0
  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.scrollTo(0, 0);
    }
    if (mainRef.current) {
      mainRef.current.scrollTop = 0;
    }
  }, [currentView]);

  // 1. Loading state while checking authentication
  if (authChecking) {
    return (
      <div className="min-h-screen bg-[#070b14] text-white flex flex-col items-center justify-center p-4">
        <div className="flex flex-col items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-teal-600/20 border border-teal-500/30 flex items-center justify-center text-teal-400 shadow-xl shadow-teal-500/10">
            <Heart className="w-7 h-7 fill-teal-500 text-teal-500 animate-pulse" />
          </div>
          <div className="flex items-center gap-2 text-sm font-semibold text-slate-300">
            <Loader2 className="h-4 w-4 animate-spin text-teal-400" />
            <span>Verifying secure session...</span>
          </div>
          <p className="text-xs text-slate-500">KindLink Asansol Mutual Aid Network</p>
        </div>
      </div>
    );
  }

  // 2. Unauthenticated: redirected to /login, showing fallback transition
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#070b14] text-white flex flex-col justify-center items-center px-4 py-8">
        <div className="text-center max-w-sm">
          <Loader2 className="h-6 w-6 animate-spin text-teal-400 mx-auto mb-3" />
          <p className="text-sm font-semibold text-slate-300">Redirecting to login...</p>
        </div>
      </div>
    );
  }

  // 3. Authenticated: Render the main application shell
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col w-full max-w-[100vw] overflow-x-hidden">
      {/* Top App Bar */}
      <Header />

      {/* Main Container Layout */}
      <div className="flex-1 flex max-w-[1920px] w-full mx-auto min-w-0 overflow-x-hidden">
        {/* Left Sidebar on tablet, laptop, desktop */}
        <Sidebar />

        {/* Dynamic Center Stage Views */}
        <main ref={mainRef} className="flex-1 flex flex-col min-w-0 overflow-y-auto overflow-x-hidden">
          {currentView === 'home' && <HomeView />}
          {currentView === 'requests' && <RequestsView />}
          {currentView === 'map' && <MapView />}
          {currentView === 'new' && <NewRequestWizard />}
          {currentView === 'profile' && <ProfileView />}
          {currentView === 'settings' && <SettingsView />}
        </main>
      </div>

      {/* Mobile Bottom Tab Bar */}
      <BottomTabBar />

      {/* First Visit Onboarding Modal */}
      <WelcomeModal />

      {/* First-Time Auto-Language Notice Banner */}
      <AutoLanguageNotice />

      {/* Global Command Palette & Quick Action Navigator */}
      <CommandPalette />
    </div>
  );
}
